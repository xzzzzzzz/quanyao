import code from './codes'
export default code